---
name: ctf-triage
description: START HERE for any CTF challenge, flag hunt or find-the-flag task. Classifies the challenge (file, URL, text, screenshot), applies the clue-first method, routes to the right ctf specialist skill.
---

> **Browser / sandbox mode (read first).** This copy of the skill is built for claude.ai and
> cloud sessions. You are running in a remote Linux sandbox, **not** on the challenge machine.
> The user is on a locked-down Windows PC with only a browser (no admin, nothing installable)
> and gets challenge files to you by uploading them.
> - Bundled scripts live next to this SKILL.md (`scripts/...`); sibling skills (`ctf-*`,
>   `investigation`) sit in the same parent directory. Run scripts by absolute path.
> - Work on the files the user uploaded; save anything the user should look at (images,
>   decoded files) as an output file they can open.
> - Assume you **cannot reach challenge servers, `nc` services or the campus network** unless a
>   quick probe proves otherwise (a cloud session with full network access can reach public
>   HTTP hosts; the claude.ai chat sandbox cannot). When a live target is out of reach, never
>   invent its response: give the user exact commands to run on their PC and ask them to paste
>   the output or upload the saved response. No-admin Windows options: PowerShell
>   `curl.exe -i -s URL`, `curl.exe -o out.bin URL`, `Get-FileHash`, `Format-Hex`,
>   `certutil -decode`, `tar -xf`; or browser DevTools (Network tab "Copy as cURL",
>   Application tab for cookies/storage, Console `fetch`).
> - Tool hints below that say `brew install ...` do not apply here. Prefer pure Python; try
>   `pip install <pkg>` when a library is needed; if a native tool is missing, reimplement the
>   step in Python rather than stopping.
> - Scope is unchanged: organisers' challenge systems only.

# CTF Triage & Router

You are solving an **authorized** CTF (Flag Hunters 2026, AFKAR / IIT Delhi — Abu Dhabi, or
practice). Work **only** on the organisers' provided challenge systems/files — attacking anything
else is out of scope and a disqualification. Flag format: **`flag{...}`**, and the braces hold
**only letters, numbers, and underscores**. AI tools are allowed; that's why this arsenal exists.

Your job here: classify fast, apply the meta that beats "designed-for-AI" challenges, and hand
off to the specialist skill with a concrete first move. **Speed comes from not re-deriving
tooling**; the specialists bundle ready-to-run scripts. **Correctness comes from clue-first
discipline and verifying offline before you submit.**

---

## 0. The 60-second intake (do this every time)

1. **Read everything given**, in this order: the challenge *title*, the *prompt text*, any
   *hints*, the *filename(s)*, then the file contents. Titles and filenames are chosen by the
   author and frequently leak the trick (a date-stamp filename was literally the RNG seed once).
2. **Identify what you physically have**: a URL/service? a file? a screenshot? plain text? If a
   screenshot of the challenge page, transcribe the prompt, the Download/attachment, and the
   hint buttons.
3. **Fingerprint any file** before guessing:
   ```bash
   file FILENAME; xxd FILENAME | head; stat FILENAME
   exiftool FILENAME 2>/dev/null
   strings -n 8 FILENAME | grep -iE 'flag\{|ctf|pass|secret|key' | head
   ```
4. **Grep for the flag immediately** — some flags sit in plain sight:
   ```bash
   python3 -I scripts/flag_grep.py FILENAME        # raw bytes + encodings + leet variants
   ```
   If that prints a `flag{...}`, confirm it's the *final* flag and not a mid-chain artifact
   (see §0.5), then you're done. It costs 2 seconds either way.

---

## 0.5 One challenge, or a step in a chain? (don't mistake a waypoint for the flag)

Flag Hunters is built as **one long investigation**, not a pile of isolated tasks: the finals are a
**digital murder mystery** where *more flags = more story*, and many individual challenges are
themselves **multi-stage** — stage 1's output is the *key to stage 2*, not the prize. Before you
call a thread done, decide which you're holding:

- **The output is itself `flag{...}`** → a real flag. Record it, then (finals) check whether the
  story now unlocks a *new* lead — a flag is a checkpoint, not necessarily the end.
- **The output is anything else** — a URL, password, coordinates, a filename, a decoded sentence,
  another ciphertext/blob → it's a **waypoint**. Do NOT stop and do NOT submit it. Feed it back
  through the intake (§0) and **re-triage**: the next stage is usually a *different* category than
  the one you just solved (crypto → a URL → web → a download → forensics …).
- **Stop condition:** only a *verified* `flag{...}` ends a thread. A clean artifact but no flag
  means the challenge isn't finished — follow the artifact.

**Finals default:** a whole machine / a story / multiple flags → load **investigation** first; it's
the spine that carries clues between stages and dispatches each one back here. A single provided
file with no story → treat it as possibly-multi-stage, but skip the investigation overhead until a
second stage actually appears.

---

## 1. Classify the category (signal table)

Match the strongest signal; when two fit, run both specialists in parallel (see §4).

| Signal | Category → skill |
|---|---|
| `.pem`, `n =`/`e =`/`c =`, ciphertext blob, "encrypt/decrypt", cipher name, hashes, a seed/timestamp | **ctf-crypto** |
| A URL, login page, cookies, `robots.txt`, API, "admin", HTTP, `nc`-less web service | **ctf-web** |
| `.zip/.7z/.rar/.pcap/.img/.raw/.E01`, disk/memory dump, logs, "recover/hidden file", nested archives, invisible/zero-width text | **ctf-forensics** |
| Image (PNG/JPG/BMP/GIF) or audio (WAV/MP3) that "looks blank"/"has a message", LSB, spectrogram, "listen/hum/frequency" | **ctf-stego** |
| A photo to locate, "where was this", landmark/sign, a username/handle, EXIF GPS, social media | **ctf-osint** |
| An executable (ELF/PE/`.exe`/`.pyc`/`.class`/.NET), crackme, keygen, "what input is correct", obfuscated program | **ctf-rev** |
| An ELF **plus a `nc host port` service**, "pwn", overflow, "get a shell", segfault, ROP | **ctf-binary** |
| A mystery text blob, unknown encoding, esolang, QR/barcode, JSFuck, emoji/symbol cipher | **ctf-misc** |
| A whole system / "victim's computer" to explore, a story/visual-novel, multiple flags across files & accounts | **investigation** |

**Disambiguators:** a binary with *no* network service and a "find the password" prompt → rev,
not binary/pwn. An image whose text is readable but encoded → decode (misc/crypto), not stego.
A log file → forensics. "Looks like noise" audio/image → stego.

### Fast-path (skip the overhead when it's obviously easy)
If the challenge is trivially identifiable — a single small file, an obvious encoding (base64/hex/rot), a one-step decode — solve it directly; DON'T spend tool calls loading a full category SKILL.md first. Load the category skill only when (a) the first obvious attempt fails, or (b) the challenge is non-trivial (binary/pwn/crypto-with-math/multi-step). Rationale: on easy challenges the skill-read overhead (~2x the tool calls, measured) buys nothing; reserve it for where it pays.

---

## 2. The clue-first meta (this is the edge — read `references/clue-first.md`)

These challenges are built assuming every team uses AI, so the naive "ask the model to decrypt
it" path is usually **defended**. The intended solve is a human-spottable **clue or leaked
artifact**. Internalize these principles (full detail + war stories in
`references/clue-first.md`):

- **Mine the artifact before attacking it.** Filename, metadata, timestamps, EXIF, PDF dates,
  object IDs, author fields — the key often leaks here because the *content* is encrypted but the
  *wrapper* isn't. (A PDF whose filename was its creation timestamp = the PRNG seed = the
  password. We'd never crack RC4; we didn't have to.)
- **Misdirection is a signpost.** "don't look here", "nobody should read this", "these files are
  NOT important", a `Trash/` or `dontlook/` folder — the author is pointing at the answer.
- **Error-type is an oracle (read it carefully).** The real tell is usually *success*; failing
  that, a candidate that throws a *different error type* or fails at a *later stage* than all the
  others is likely right. Don't be fooled by wrong passwords that share one error type and differ
  only in the message text — that's noise, not the oracle.
- **Translate prose clues literally.** "8 rails", "move up by 5", "seconds ending in :02",
  ordered name fragments → turn each phrase directly into a parameter or one regex.
- **Brute force is the LAST resort**, not the first. If you're about to brute a large space,
  stop: you've probably missed the clue. Re-read the prompt and the artifact.
- **But don't loop on a clue that isn't there.** Clue-first is a *prior, not a guarantee*. The
  finals are harder than prelims and some challenges have **no leaked artifact** — the intended
  path is genuine technique (real cryptanalysis, a full web/exploit chain, reversing the binary).
  Rule of thumb: ~10 min of artifact-mining with no thread → switch to the specialist's core
  method and treat it as a real problem, not a riddle. Mistaking a hard challenge for a trick
  burns the clock.

---

## 3. Time-box & hint strategy (finals are timed; fewer hints score better)

- Each problem has **3 hints**; using fewer is favoured for qualification. Treat a hint as a
  resource you spend only after a **genuine attempt**.
- Suggested budget per challenge: **~8–10 min** of the fast path + the top-2 specialist moves
  before taking **hint 1**; another focused push before **hint 2**; hint 3 only when truly stuck
  or when the clock makes it worth it.
- **Prefer the cheap high-yield checks first** (strings/grep/metadata/view-source) — they solve a
  surprising fraction instantly and cost almost nothing.
- Keep a one-line note of what you've ruled out, so a hint snaps into place instead of restarting.
- Know when to move on: in a 4–6 hr finals with many flags, a stuck hard challenge is worth less
  than two easy ones you haven't opened yet. Park it, bank others, come back.

### What counts as progress (and when to stop)
**Progress =** a new verified fact · a hypothesis *eliminated* · a working primitive
(leak/oracle/decode) · a measured search-space reduction · a reproducible flag candidate · a broad
unknown replaced by an **exact blocker**.
**NOT progress =** re-explaining the same output · changing payload punctuation with no new
mechanism · rerunning an unchanged command · trying an attack the evidence doesn't support ·
inventing more flags from story themes.
**After 3 no-progress actions in a row:** do ONE evidence-backed pivot; if a 2nd family also yields
no new hard evidence → **park it** and bank easier flags; only escalate (harder model / deeper tool)
when you have an exact blocker *plus* new verified evidence.

### Submission governor (don't burn attempts)
Before submitting, a candidate must be **reproducible** and **format-valid** (`flag{[A-Za-z0-9_]+}`).
If few submissions remain: ≤10 attempts → add an independent consistency check; ≤3 attempts → get
explicit user go-ahead. A **rejected flag is evidence** — record it exactly and never resubmit a
cosmetic permutation without new derivation. (We verify **offline** first — see §5 and ctf-crypto's
in-process verifier.)

---

## 4. Route — and parallelize when ambiguous

- **Clear category** → load that specialist skill and execute its FAST-PATH.
- **Ambiguous (2–3 plausible)** → spin up the specialists **in parallel** (sub-agents) on the
  same artifact and take the first that lands a verified flag. This is the time-saver under
  pressure; the user has endorsed fan-out.
- **A provided machine / multi-flag story** → load **investigation** first; it will dispatch the
  specialists per artifact it uncovers.

Hand off with a concrete first move, e.g. *"→ ctf-stego: this is a near-white PNG; run
image_amplify.py with tolerance 3 first."*

---

## 5. The flag: recognize, normalize, verify

- **Recognize**: `flag{...}`, contents are `[A-Za-z0-9_]+`. Other events vary the wrapper
  (`FLAG{}`, `ctf{}`) — here it's `flag{}`. Watch for **ligatures** in extracted text (`ﬂ`/`ﬁ`
  break a `flag\{` regex) and glyph confusion in drawn/faint text (`l/1/!`, `O/0`, `s/5`, `B/8`).
- **Normalize / variants to try** when a flag is rejected: leetspeak swaps (`a↔4 e↔3 o↔0 i↔1
  s↔5 t↔7`), case changes, ASCII-folding accents (`ö→o`), spaces→underscores. `flag_grep.py`
  surfaces these automatically.
- **Verify before submitting.** Build or use an **offline verifier** when possible (test a
  candidate password/key in-process, as the crypto skill does) rather than burning a submission.
  Confirm the whole flag is captured (no truncation, right delimiters).

Bundled helper: `python3 -I scripts/flag_grep.py <file-or-dir>` — recursively greps raw bytes,
common encodings (base64/hex/rot), and leet variants for `flag{...}`.

---

## Reference files
- `references/clue-first.md` — the full methodology + the war-story pattern library. Read it when
  a challenge resists the obvious path.
- `references/playbook.md` — a one-screen **pattern → technique → script** lookup table. Scan it
  to pick a move fast.
